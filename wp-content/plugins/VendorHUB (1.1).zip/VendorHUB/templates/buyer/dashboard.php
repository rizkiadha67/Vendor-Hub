<?php
/**
 * Buyer Dashboard Template
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$current_user = wp_get_current_user();
?>

<div class="vh-container">
    <div class="vh-dashboard-header">
        <h1><?php printf( __( 'Hello, %s!', 'vendorhub' ), esc_html( $current_user->display_name ) ); ?></h1>
        <p class="text-muted"><?php _e( 'Post tenders, request quotations, and find the best vendors for your needs.', 'vendorhub' ); ?></p>
    </div>

    <div class="vh-grid">
        <!-- Quick Stats -->
        <div class="vh-card">
            <h3><?php _e( 'Active RFQs', 'vendorhub' ); ?></h3>
            <p class="h1">0</p>
            <a href="<?php echo admin_url( 'post-new.php?post_type=vh_rfq' ); ?>" class="vh-btn vh-btn-primary">
                <?php _e( 'Create RFQ', 'vendorhub' ); ?>
            </a>
        </div>

        <div class="vh-card">
            <h3><?php _e( 'Active Tenders', 'vendorhub' ); ?></h3>
            <p class="h1">0</p>
            <a href="<?php echo admin_url( 'post-new.php?post_type=vh_tender' ); ?>" class="vh-btn vh-btn-primary">
                <?php _e( 'Publish Tender', 'vendorhub' ); ?>
            </a>
        </div>

        <div class="vh-card">
            <h3><?php _e( 'Saved Vendors', 'vendorhub' ); ?></h3>
            <p class="h1">0</p>
            <a href="#" class="vh-btn vh-btn-primary">
                <?php _e( 'Directory', 'vendorhub' ); ?>
            </a>
        </div>
    </div>
</div>
