<?php
/**
 * Vendor and Product Management for NiagaHUB
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VH_Vendor_Manager {

    public static function init() {
        add_action( 'show_user_profile', array( __CLASS__, 'add_vendor_fields' ) );
        add_action( 'edit_user_profile', array( __CLASS__, 'add_vendor_fields' ) );
        add_action( 'personal_options_update', array( __CLASS__, 'save_vendor_fields' ) );
        add_action( 'edit_user_profile_update', array( __CLASS__, 'save_vendor_fields' ) );

        // Add Tender meta fields
        add_action( 'add_meta_boxes_vh_tender', array( __CLASS__, 'add_tender_metaboxes' ) );
        add_action( 'save_post_vh_tender', array( __CLASS__, 'save_tender_meta' ) );

        add_action( 'add_meta_boxes_vh_product', array( __CLASS__, 'add_product_metaboxes' ) );
        add_action( 'save_post_vh_product', array( __CLASS__, 'save_product_meta' ) );
    }

    /**
     * Tender Meta Boxes (Budget, Deadline)
     */
    public static function add_tender_metaboxes() {
        add_meta_box( 'vh_tender_settings', __( 'Tender Details', 'vendorhub' ), array( __CLASS__, 'render_tender_metabox' ), 'vh_tender', 'side' );
    }

    public static function render_tender_metabox( $post ) {
        $budget = get_post_meta( $post->ID, '_vh_tender_budget', true );
        $deadline = get_post_meta( $post->ID, '_vh_tender_deadline', true );
        ?>
        <p>
            <label for="vh_tender_budget"><?php _e('Estimated Budget (Rp)', 'vendorhub'); ?></label>
            <input type="number" name="vh_tender_budget" id="vh_tender_budget" value="<?php echo esc_attr($budget); ?>" style="width:100%;" />
        </p>
        <p>
            <label for="vh_tender_deadline"><?php _e('Deadline Date', 'vendorhub'); ?></label>
            <input type="date" name="vh_tender_deadline" id="vh_tender_deadline" value="<?php echo esc_attr($deadline); ?>" style="width:100%;" />
        </p>
        <?php
    }

    public static function save_tender_meta( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( isset( $_POST['vh_tender_budget'] ) ) update_post_meta( $post_id, '_vh_tender_budget', sanitize_text_field( $_POST['vh_tender_budget'] ) );
        if ( isset( $_POST['vh_tender_deadline'] ) ) update_post_meta( $post_id, '_vh_tender_deadline', sanitize_text_field( $_POST['vh_tender_deadline'] ) );
    }

    public static function add_product_metaboxes_init() {
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_product_metaboxes' ) );
        add_action( 'save_post_vh_product', array( __CLASS__, 'save_product_meta' ) );
    }

    /**
     * Add Vendor specific fields to User Profile
     */
    public static function add_vendor_fields( $user ) {
        if ( ! in_array( 'vendor', (array) $user->roles ) && ! in_array( 'administrator', (array) $user->roles ) ) {
            return;
        }

        $verified = get_user_meta( $user->ID, 'vh_verified', true );
        $location = get_user_meta( $user->ID, 'vh_location', true );
        ?>
        <h3><?php _e( 'NiagaHUB Vendor Information', 'vendorhub' ); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="vh_vendor_logo"><?php _e( 'Vendor Logo', 'vendorhub' ); ?></label></th>
                <td>
                    <?php 
                    $logo_id = get_user_meta( $user->ID, 'vh_vendor_logo', true );
                    $logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'thumbnail' ) : '';
                    ?>
                    <div id="vh-logo-preview" style="margin-bottom: 10px;">
                        <?php if ( $logo_url ) : ?>
                            <img src="<?php echo esc_url( $logo_url ); ?>" style="max-width: 100px; border: 1px solid #ccc; border-radius: 50%;" />
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="vh_vendor_logo" id="vh_vendor_logo" value="<?php echo esc_attr( $logo_id ); ?>" />
                    <button type="button" class="button vh-upload-button" id="vh_upload_logo_btn"><?php _e( 'Upload Logo', 'vendorhub' ); ?></button>
                    <button type="button" class="button vh-remove-button" id="vh_remove_logo_btn" <?php echo ! $logo_id ? 'style="display:none;"' : ''; ?>><?php _e( 'Remove', 'vendorhub' ); ?></button>
                    <p class="description"><?php _e( 'Recommended size: 300x300px (format: .png, .jpg)', 'vendorhub' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="vh_location"><?php _e( 'Business Location', 'vendorhub' ); ?></label></th>
                <td>
                    <input type="text" name="vh_location" id="vh_location" value="<?php echo esc_attr( $location ); ?>" class="regular-text" />
                    <p class="description"><?php _e( 'City or region where your business is located.', 'vendorhub' ); ?></p>
                </td>
            </tr>
            <?php if ( current_user_can( 'manage_options' ) ) : ?>
            <tr>
                <th><label for="vh_verified"><?php _e( 'Verified Vendor', 'vendorhub' ); ?></label></th>
                <td>
                    <input type="checkbox" name="vh_verified" id="vh_verified" value="1" <?php checked( $verified, '1' ); ?> />
                    <span class="description"><?php _e( 'Check to mark this vendor as verified (Admin only).', 'vendorhub' ); ?></span>
                </td>
            </tr>
            <?php endif; ?>
        </table>
        <script>
        jQuery(document).ready(function($) {
            $('#vh_upload_logo_btn').click(function(e) {
                e.preventDefault();
                var custom_uploader = wp.media({
                    title: '<?php _e( "Select Vendor Logo", "vendorhub" ); ?>',
                    button: { text: '<?php _e( "Use this logo", "vendorhub" ); ?>' },
                    multiple: false
                }).on('select', function() {
                    var attachment = custom_uploader.state().get('selection').first().toJSON();
                    $('#vh-logo-preview').html('<img src="' + attachment.url + '" style="max-width: 100px; border: 1px solid #ccc; border-radius: 50%;" />');
                    $('#vh_vendor_logo').val(attachment.id);
                    $('#vh_remove_logo_btn').show();
                }).open();
            });

            $('#vh_remove_logo_btn').click(function() {
                $('#vh-logo-preview').html('');
                $('#vh_vendor_logo').val('');
                $(this).hide();
            });
        });
        </script>
        <?php
    }

    public static function save_vendor_fields( $user_id ) {
        if ( ! current_user_can( 'edit_user', $user_id ) ) {
            return;
        }
        update_user_meta( $user_id, 'vh_location', sanitize_text_field( $_POST['vh_location'] ) );
        update_user_meta( $user_id, 'vh_vendor_logo', sanitize_text_field( $_POST['vh_vendor_logo'] ) );
        
        if ( current_user_can( 'manage_options' ) ) {
            update_user_meta( $user_id, 'vh_verified', isset( $_POST['vh_verified'] ) ? '1' : '0' );
        }
    }

    /**
     * Product Meta Boxes (MOQ, Unit)
     */
    public static function add_product_metaboxes() {
        add_meta_box( 'vh_product_settings', __( 'B2B Settings', 'vendorhub' ), array( __CLASS__, 'render_product_metabox' ), 'vh_product', 'side' );
    }

    public static function render_product_metabox( $post ) {
        $moq = get_post_meta( $post->ID, '_vh_moq', true );
        $unit = get_post_meta( $post->ID, '_vh_unit', true );
        ?>
        <p>
            <label for="vh_moq"><?php _e( 'Min Order Quantity (MOQ)', 'vendorhub' ); ?></label>
            <input type="number" name="vh_moq" id="vh_moq" value="<?php echo esc_attr( $moq ); ?>" style="width:100%;" />
        </p>
        <p>
            <label for="vh_unit"><?php _e( 'Unit (e.g. Box, Pcs, Kg)', 'vendorhub' ); ?></label>
            <input type="text" name="vh_unit" id="vh_unit" value="<?php echo esc_attr( $unit ); ?>" style="width:100%;" />
        </p>
        <?php
    }

    public static function save_product_meta( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( isset( $_POST['vh_moq'] ) ) update_post_meta( $post_id, '_vh_moq', sanitize_text_field( $_POST['vh_moq'] ) );
        if ( isset( $_POST['vh_unit'] ) ) update_post_meta( $post_id, '_vh_unit', sanitize_text_field( $_POST['vh_unit'] ) );
    }
}

VH_Vendor_Manager::init();

/**
 * Helper: Display Verified Badge
 */
function vh_verified_badge( $user_id ) {
    $verified = get_user_meta( $user_id, 'vh_verified', true );
    if ( $verified === '1' ) {
        return '<span class="vh-badge vh-badge-verified">' . __( 'Verified', 'vendorhub' ) . '</span>';
    }
    return '';
}
