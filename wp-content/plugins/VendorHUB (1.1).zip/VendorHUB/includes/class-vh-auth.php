<?php
/**
 * Authentication Handler for NiagaHUB
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VH_Auth {

    public static function init() {
        add_action( 'wp_ajax_vh_ajax_register', array( __CLASS__, 'handle_registration' ) );
        add_action( 'wp_ajax_nopriv_vh_ajax_register', array( __CLASS__, 'handle_registration' ) );
        
        add_action( 'wp_ajax_vh_ajax_login', array( __CLASS__, 'handle_login' ) );
        add_action( 'wp_ajax_nopriv_vh_ajax_login', array( __CLASS__, 'handle_login' ) );

        add_action( 'wp_ajax_vh_save_profile', array( __CLASS__, 'handle_save_profile' ) );
        add_action( 'wp_ajax_vh_add_product', array( __CLASS__, 'handle_add_product' ) );
        add_action( 'wp_ajax_vh_add_tender', array( __CLASS__, 'handle_add_tender' ) );
    }

    /**
     * Handle AJAX Registration
     */
    public static function handle_registration() {
        check_ajax_referer( 'vh-auth-nonce', 'security' );

        $username = sanitize_user( $_POST['user_login'] );
        $email    = sanitize_email( $_POST['user_email'] );
        $role     = sanitize_text_field( $_POST['user_role'] );
        $password = wp_generate_password();

        if ( empty( $username ) || empty( $email ) ) {
            wp_send_json_error( __( 'Please fill in all required fields.', 'vendorhub' ) );
        }

        if ( $role === 'vendor' && empty( $_POST['vh_nib'] ) ) {
            wp_send_json_error( __( 'NIB / Izin Usaha is required for vendors.', 'vendorhub' ) );
        }

        if ( email_exists( $email ) ) {
            wp_send_json_error( __( 'This email is already registered.', 'vendorhub' ) );
        }

        $user_id = wp_create_user( $username, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            wp_send_json_error( $user_id->get_error_message() );
        }

        // Set User Role
        $user = new WP_User( $user_id );
        $user->set_role( $role );

        // Save Metadata
        if ( isset( $_POST['vh_company_name'] ) ) {
            update_user_meta( $user_id, 'vh_company_name', sanitize_text_field( $_POST['vh_company_name'] ) );
        }
        if ( isset( $_POST['vh_location'] ) ) {
            update_user_meta( $user_id, 'vh_location', sanitize_text_field( $_POST['vh_location'] ) );
        }
        if ( $role === 'vendor' && !empty( $_POST['vh_nib'] ) ) {
            update_user_meta( $user_id, 'vh_nib', sanitize_text_field( $_POST['vh_nib'] ) );
        }
        update_user_meta( $user_id, 'vh_role', $role );

        // Send Email with Password
        wp_new_user_notification( $user_id, null, 'both' );

        // Auto Login after registration
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id );

        wp_send_json_success( array(
            'message' => __( 'Registration successful! Redirecting...', 'vendorhub' ),
            'redirect' => site_url( '/dashboard' )
        ) );
    }

    /**
     * Handle AJAX Login
     */
    public static function handle_login() {
        check_ajax_referer( 'vh-auth-nonce', 'security' );

        $info = array();
        $info['user_login']    = $_POST['log'];
        $info['user_password'] = $_POST['pwd'];
        $info['remember']      = true;

        $user_signon = wp_signon( $info, is_ssl() );

        if ( is_wp_error( $user_signon ) ) {
            wp_send_json_error( __( 'Invalid username or password.', 'vendorhub' ) );
        } else {
            wp_send_json_success( array(
                'message' => __( 'Login successful! Redirecting...', 'vendorhub' ),
                'redirect' => site_url( '/dashboard' )
            ) );
        }
    }

    /**
     * Handle Profile Save
     */
    public static function handle_save_profile() {
        check_ajax_referer( 'vh-auth-nonce', 'security' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( __( 'You must be logged in.', 'vendorhub' ) );
        }

        $user_id = get_current_user_id();

        if ( ! empty( $_POST['vh_company_name'] ) ) {
            update_user_meta( $user_id, 'vh_company_name', sanitize_text_field( $_POST['vh_company_name'] ) );
        }
        if ( ! empty( $_POST['vh_location'] ) ) {
            update_user_meta( $user_id, 'vh_location', sanitize_text_field( $_POST['vh_location'] ) );
        }
        if ( ! empty( $_POST['display_name'] ) ) {
            wp_update_user( array( 'ID' => $user_id, 'display_name' => sanitize_text_field( $_POST['display_name'] ) ) );
        }
        if ( ! empty( $_POST['user_pass'] ) && strlen( $_POST['user_pass'] ) >= 6 ) {
            wp_set_password( $_POST['user_pass'], $user_id );
        }

        // Save vendor logo (attachment ID) — handle both set and clear
        if ( isset( $_POST['vh_vendor_logo'] ) ) {
            $logo_id = absint( $_POST['vh_vendor_logo'] );
            if ( $logo_id > 0 ) {
                update_user_meta( $user_id, 'vh_vendor_logo', $logo_id );
            } else {
                delete_user_meta( $user_id, 'vh_vendor_logo' );
            }
        }

        wp_send_json_success( array( 'message' => __( 'Profil berhasil disimpan!', 'vendorhub' ) ) );
    }

    /**
     * Handle Add Product (Vendor)
     */
    public static function handle_add_product() {
        check_ajax_referer( 'vh-auth-nonce', 'security' );

        if ( ! is_user_logged_in() || ! vh_is_vendor() ) {
            wp_send_json_error( __( 'Unauthorized.', 'vendorhub' ) );
        }

        $title = sanitize_text_field( $_POST['post_title'] ?? '' );
        if ( empty( $title ) ) {
            wp_send_json_error( __( 'Judul produk tidak boleh kosong.', 'vendorhub' ) );
        }

        $post_id = wp_insert_post( array(
            'post_type'    => 'vh_product',
            'post_title'   => $title,
            'post_content' => wp_kses_post( $_POST['post_content'] ?? '' ),
            'post_status'  => 'publish',
            'post_author'  => get_current_user_id(),
        ) );

        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( $post_id->get_error_message() );
        }

        update_post_meta( $post_id, '_vh_price', sanitize_text_field( $_POST['vh_price'] ?? '' ) );
        update_post_meta( $post_id, '_vh_moq',   sanitize_text_field( $_POST['vh_moq'] ?? '1' ) );
        update_post_meta( $post_id, '_vh_unit',  sanitize_text_field( $_POST['vh_unit'] ?? 'Unit' ) );

        wp_send_json_success( array(
            'message'  => __( 'Produk berhasil ditambahkan!', 'vendorhub' ),
            'redirect' => add_query_arg( 'tab', 'products', site_url( '/dashboard' ) ),
        ) );
    }

    /**
     * Handle Add Tender (Buyer)
     */
    public static function handle_add_tender() {
        check_ajax_referer( 'vh-auth-nonce', 'security' );

        if ( ! is_user_logged_in() || ! vh_is_buyer() ) {
            wp_send_json_error( __( 'Unauthorized.', 'vendorhub' ) );
        }

        $title = sanitize_text_field( $_POST['post_title'] ?? '' );
        if ( empty( $title ) ) {
            wp_send_json_error( __( 'Judul tender tidak boleh kosong.', 'vendorhub' ) );
        }

        $post_id = wp_insert_post( array(
            'post_type'    => 'vh_tender',
            'post_title'   => $title,
            'post_content' => wp_kses_post( $_POST['post_content'] ?? '' ),
            'post_status'  => 'publish',
            'post_author'  => get_current_user_id(),
        ) );

        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( $post_id->get_error_message() );
        }

        update_post_meta( $post_id, '_vh_tender_budget',   sanitize_text_field( $_POST['vh_tender_budget'] ?? '' ) );
        update_post_meta( $post_id, '_vh_tender_deadline', sanitize_text_field( $_POST['vh_tender_deadline'] ?? '' ) );

        wp_send_json_success( array(
            'message'  => __( 'Tender berhasil dibuat!', 'vendorhub' ),
            'redirect' => add_query_arg( 'tab', 'tenders', site_url( '/dashboard' ) ),
        ) );
    }
}

VH_Auth::init();
